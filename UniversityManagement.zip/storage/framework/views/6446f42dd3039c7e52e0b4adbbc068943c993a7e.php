
<?php $__env->startSection('content'); ?>
   
      
   <div class="row justify-content-center">
        <div class="col-12 col-lg-12 mt-2 mb-2">
               <?php echo $__env->make('administrator.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-12 col-lg-12 mt-2 mb-2">
            <div class="card">
                <div class="card-body">
                    
                    <?php if(\Carbon\Carbon::now()->diffInDays(\Carbon\Carbon::parse($registrationTime)) <= 7): ?>
                    <div class="d-flex justify-content-center">
                        <a class="btn btn-primary" href="<?php echo e(route('student.course.registration')); ?>" role="button">Go to Registration</a>
                    </div>
                    <?php endif; ?>
       
                </div>
            </div>
        </div>
    </div>
      
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\University Management\UniversityManagement\resources\views/user/dashboard/home.blade.php ENDPATH**/ ?>