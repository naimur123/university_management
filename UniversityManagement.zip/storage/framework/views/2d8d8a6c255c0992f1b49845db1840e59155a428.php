
<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-12 col-lg-12 mt-2 mb-2">
               <?php echo $__env->make('administrator.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-12 col-lg-12 mt-2 mb-2">
            <div class="card">
                <div class="card-body">
                    <form action="<?php echo e($form_url); ?>" class="row form-horizontal" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="col-12 mt-10">
                            <h3>Student <?php echo e($title ?? ""); ?></h3>
                            <input type="hidden" name="id" value="<?php echo e($data->id ?? 0); ?>">
                            <input type="hidden" name="name" value="<?php echo e($data->program ?? $name); ?>">
                            <hr/>
                        </div>
    
                        
                        <!-- Student First Name -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>First Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control " value="<?php echo e(old("first_name") ?? ($data->first_name ?? "")); ?> " name="first_name">
                                <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <!-- Student Middle Name -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Middle Name <span class="text-danger">*</span></label>
                                <input type="text" class="form-control " value="<?php echo e(old("middle_name") ?? ($data->middle_name ?? "")); ?> " name="middle_name">
                                <?php $__errorArgs = ['middle_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
    
                        <!-- Student Last Name -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Last Name </label>
                                <input type="text" class="form-control " value="<?php echo e(old("last_name") ?? ($data->last_name ?? "")); ?> " name="last_name" required >
                                <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <!-- Student Father Name -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Father Name </label>
                                <input type="text" class="form-control " value="<?php echo e(old("father_name") ?? ($data->father_name ?? "")); ?> " name="father_name" required >
                                <?php $__errorArgs = ['father_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <!-- Student Mother Name -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Mother Name </label>
                                <input type="text" class="form-control " value="<?php echo e(old("mother_name") ?? ($data->mother_name ?? "")); ?> " name="mother_name" required >
                                <?php $__errorArgs = ['mother_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <!-- Student Email -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" class="form-control " value="<?php echo e(old("email") ?? ($data->email ?? "")); ?> " name="email" required >
                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <!-- Student DOB -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Date Of Birth</label>
                                <input type="date" class="form-control " value="<?php echo e(old("dob") ?? ($data->dob ?? "")); ?>" name="dob" required >
                                <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
    
                        <!-- Student Phone Number -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="tel" class="form-control " value="<?php echo e(old("mobile") ?? ($data->mobile ?? "")); ?>" name="mobile" required >
                                <?php $__errorArgs = ['mobile'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
    
                        <!--Sex -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Sex</label>
                                <select class="form-control select2" name="sex">
                                    <option value="m">Male</option>
                                    <option value="f">Female</option>
                                    <option value="o">Others</option>                           
                                </select>
                            </div>
                        </div>
    
                        <!-- Nationality -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Nationality</label>
                                <input type="text" class="form-control " value="<?php echo e(old("nationality") ?? ($data->nationality ?? "")); ?>" name="nationality">
                                <?php $__errorArgs = ['nationality'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
    
                        <!-- Religion -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Religion</label>
                                <input type="text" class="form-control " value="<?php echo e(old("religion") ?? ($data->religion ?? "")); ?>" name="religion">
                                <?php $__errorArgs = ['religion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
    
                        <!--Marital Status -->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Marital Status</label>
                                <select class="form-control select2" name="maritalstatus">
                                    <option value="single">Single</option>
                                    <option value="married">Married</option>
                                    <option value="divorced">Divorced</option>                           
                                </select>
                            </div>
                        </div>

                        <!--Department-->
                        <div class="col-12 col-sm-6 col-md-4">
                            <div class="form-group">
                                <label>Department<span class="text-danger">*</span></label>
                                <select class="form-control select2" name="department_id" required >
                                     <option value="<?php echo e($department->first()->id); ?>" <?php echo e(old('department_id') && old('department_id') == $department->first()->id ? 'selected' : (isset($data->department) && $data->department == $department->first()->id ? "selected" : Null)); ?>> <?php echo e($department->first()->name); ?> </option>                           
                                   </select>
                            </div>
                        </div>
                    
                        <!-- Present Address -->
                        <div class="col-4">
                            <div class="form-group">
                                <label>Present Address</label>
                                <textarea class="form-control editor" name="presentaddress"><?php echo e(old("presentaddress") ?? ($data->presentaddress ?? "")); ?></textarea>
                                <?php $__errorArgs = ['presentaddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
    
                        <!-- Permanent Address -->
                        <div class="col-4">
                            <div class="form-group">
                                <label>Permanent Address</label>
                                <textarea class="form-control editor" name="permanentaddress"><?php echo e(old("permanentaddress") ?? ($data->permanentaddress ?? "")); ?> </textarea>
                                <?php $__errorArgs = ['permanentaddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        
                        
                        <!--submit -->
                        <div class="col-12 text-right py-2">
                            <div class="form-group text-right">
                                <button type="submit" class="btn btn-info">Submit </button>
                            </div>
                        </div>
    
        </form>
    
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\University Management\UniversityManagement\resources\views/administrator/student/create.blade.php ENDPATH**/ ?>