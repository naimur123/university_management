
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-12 col-lg-12 mt-2 mb-2">
           <?php echo $__env->make('administrator.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-12 col-lg-12 mt-2 mb-2">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e($form_url); ?>" class="row form-horizontal" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="col-12 mt-10">
                        <h3>CSE <?php echo e($title ?? ""); ?></h3>
                       
                        <hr/>
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($data->id ?? 0); ?>">
                    
                    <!--Set Courses -->
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label>Course List<span class="text-danger">*</span></label>
                            <select class="form-control" id="course_id" name="course_id" required > 
                            <option value="">Choose Course</option>
                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($course->id); ?>"  <?php echo e(old('course_id') && old('course_id') == $course->id ? 'selected' : (isset($data->course_id) && $data->course_id == $course->id ? "selected" : Null)); ?>> <?php echo e($course->course_name); ?> </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                            </select>
                        </div>
                    </div>
                    <!--Set Faculty -->
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label>Available Faculty<span class="text-danger">*</span></label>
                            <select class="form-control" id="faculty_id" name="faculty_id" required >
                                
                                    
                                    <option value=""  >Choose Faculty</option>     
                                
                            </select>
                        </div>
                    </div>
                    
                    <!-- Course days -->
                    <div class="col-6 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label>Days<span class="text-danger">*</span></label>                                
                            
                                <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <label>
                                        <input type="checkbox" name="day[]" value="<?php echo e($day); ?>" <?php echo e(isset($data->day) && in_array($day, $data->day) ? 'checked' : Null); ?> >
                                        <?php echo e($day); ?>

                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <br>
                                <?php $__errorArgs = ['day'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                 <strong class="text-danger"><?php echo e($message); ?></strong>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <!-- Start time  -->
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label>Start Time<span class="text-danger">*</span></label>                                
                            <input type="time" name="start_time" class="form-control"  value="<?php echo e(isset($data->start_time) ? Carbon\Carbon::parse($data->start_time)->format('h:i') : now()->format('H:i')); ?>"  required >
                        </div>                        
                    </div>   

                     <!--Set Section -->
                     <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label>Available Section<span class="text-danger">*</span></label>
                            <select class="form-control" id="section_id" name="section_id" required >
                                
                                    
                                    <option value=""> Choose Section </option>     
                                
                            </select>
                        </div>
                    </div>

                    <!--Session-->
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label>Session</label>
                            <input class="form-control " value="<?php echo e($session ?? $data->session); ?>" name="session" readonly>
                        </div>
                    </div>
                          
                   
                    <!--submit -->
                    <div class="col-12 text-right py-2">
                        <div class="form-group text-right">
                            <button type="submit" class="btn btn-info">Submit </button>
                        </div>
                    </div>
                </form>
                
   
</div>
<script type="text/javascript">
    $(document).ready(function() {
        $('#course_id').on('change', function () {
            var courseId = this.value;
            var dpt_id = <?php echo json_encode($dpt_id); ?>;
            // console.log('<?php echo e($dataUrl); ?> ?course_id='+ courseId)
            // console.log('<?php echo e($dataUrl); ?> ?dpt_id='+ dpt_id + 'course_id='+ courseId)
            $('#faculty_id').html('');
            $('#section_id').html('');
            $.ajax({
                url: '<?php echo e($dataUrl); ?> ?dpt_id='+ dpt_id + '&course_id='+ courseId,
                type: 'GET',
                success: function(response) {
                    if(response){
                        $.each(response.faculties, function (key, value) {
                            $('#faculty_id').append('<option value="' + value
                                .id + '">' + value.first_name + '' + value.last_name + '</option>');
                        });
                        $.each(response.sections, function (key, value) {
                            $('#section_id').append('<option value="' + value
                                .id + '">' + value.name + '</option>');
                        });
                    }
                    
                }
            });
           
        });
    });
</script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\University Management\UniversityManagement\resources\views/administrator/courseschedule/create.blade.php ENDPATH**/ ?>