                 </div>
                </div>
            </div>
            
    </div>
    
    
   
</body>
</html>
<?php /**PATH H:\University Management\UniversityManagement\resources\views/administrator/includes/footer.blade.php ENDPATH**/ ?>