
<?php $__env->startSection('content'); ?>
<div class="page-body">
    <div class="card">
        <div class="card-header">
            <div class="row">
                <div class="<?php echo e(isset($create) ? 'col-10' : 'col-12'); ?>" >
                    <h5><?php echo e(ucfirst( $pageTitle)); ?></h5>
                </div>
                <?php if( isset($create) && $create ): ?>
                    <div class="col-2 text-right">
                        <a class="ajax-click-page btn btn-primary btn-sm" href="<?php echo e(url($create)); ?>">Create new</a>
                    </div>
                <?php endif; ?>
            </div>
            
        </div>
      <div class="card-body">
            <div class="dt-plugin-buttons"></div>
                <div class="dt-responsive table-responsive">
                    <table id="table" class="table table-striped table-bordered nowrap">
                        <thead class="<?php echo e(isset($tableStyleClass) ? $tableStyleClass : 'bg-primary'); ?>">
                            <tr>
                                <?php $__currentLoopData = $tableColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th> <?php echo app('translator')->get('table.'.$column); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                
                            </tr>
                        </thead>
                    </table>
                </div>
        </div>
    </div>
</div>  
  
                                                  
<script type="text/javascript">
    let table;
    $(function() {
        table = $('#table').DataTable({
            processing: true,
            serverSide: true,
            ajax: '<?php echo e(isset($dataTableUrl) && !empty($dataTableUrl) ? $dataTableUrl : URL::current()); ?>',
            columns: [
                <?php $__currentLoopData = $dataTableColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    { data: '<?php echo e($column); ?>', name: '<?php echo e($column); ?>' },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                
            ],
            "lengthMenu": [[10, 20, 50, 100, 500, 1000, -1], [10, 20, 50, 100, 500, 1000, "All"]],
            
           
        });
    });
    setInterval(function () {
          $('#table').DataTable().ajax.reload();
    }, 60000);


</script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('administrator.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\University Management\UniversityManagement\resources\views/administrator/table.blade.php ENDPATH**/ ?>