<script>
    <?php if(Session::has('error')): ?>
        toastr.error("<?php echo e(Session::get('error')); ?>")
    <?php endif; ?>
</script>

<script>
     <?php if(Session::has('success')): ?>
        toastr.success("<?php echo e(Session::get('success')); ?>")
     <?php endif; ?>
</script><?php /**PATH H:\University Management\UniversityManagement\resources\views/administrator/includes/alert.blade.php ENDPATH**/ ?>