<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>New User Welcome Email</title>
</head>
<body>
    <h1>Use this Student ID and Password to login your dashboard</h1>
    <p>Your user ID is: <?php echo e($user_id); ?></p>
    <p>Your password is: <?php echo e($password); ?></p>
</body>
</html><?php /**PATH H:\University Management\UniversityManagement\resources\views/administrator/email/welcome.blade.php ENDPATH**/ ?>