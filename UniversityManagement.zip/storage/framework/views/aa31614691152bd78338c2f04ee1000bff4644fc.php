
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-12 col-lg-12 mt-2 mb-2">
           <?php echo $__env->make('administrator.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-12 col-lg-12 mt-2 mb-2">
        <div class="card">
            <div class="card-body">
                <form action="<?php echo e($form_url); ?>" class="row form-horizontal" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="col-12 mt-10">
                        <h3><?php echo e($title ?? ""); ?></h3>
                       
                        <hr/>
                    </div>
                    <input type="hidden" name="id" value="<?php echo e($data->id ?? 0); ?>">
                    
                    <!-- Batch From -->
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label>Batch From</label>
                            <input type="text" class="form-control " value="<?php echo e(old("from") ?? ($data->from ?? "")); ?> " name="from" required >
                            <?php $__errorArgs = ['from'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!-- Batch To -->
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label>Batch To</label>
                            <input type="text" class="form-control " value="<?php echo e(old("to") ?? ($data->to ?? "")); ?> " name="to" required >
                            <?php $__errorArgs = ['to'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <strong class="text-danger"><?php echo e($message); ?></strong>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <!-- Start date  -->
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label>Start date<span class="text-danger">*</span></label>                                
                            <input type="date" name="start_date" class="form-control"  value="<?php echo e(isset($data->start_time)); ?>"  required >
                        </div>                        
                    </div>   
                    <!-- Start time  -->
                    <div class="col-12 col-sm-6 col-md-4">
                        <div class="form-group">
                            <label>Start Time<span class="text-danger">*</span></label>                                
                            <input type="time" name="start_time" class="form-control"  value="<?php echo e(isset($data->start_time) ? Carbon\Carbon::parse($data->start_time)->format('h:i') : now()->format('H:i')); ?>"  required >
                        </div>                        
                    </div>   

                    <!--submit -->
                    <div class="col-12 text-right py-2">
                        <div class="form-group text-right">
                            <button type="submit" class="btn btn-info">Submit </button>
                        </div>
                    </div>
                </form>
                
   
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\University Management\UniversityManagement\resources\views/administrator/studentregtime/create.blade.php ENDPATH**/ ?>