
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center">
    <div class="col-12 col-lg-12 mt-2 mb-2">
           <?php echo $__env->make('administrator.includes.alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-12 col-lg-12 mt-2 mb-2">
        <div class="card">
            <div class="card-body">
                <h1><?php echo e(Auth::user()->program ?? "NULL"); ?></h1>
                <?php $__currentLoopData = $registrationTime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $regTime): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($regTime->from == $id || $regTime->to == $id): ?>
                        <h1>Your Registration Page</h1>
                    <?php else: ?>
                        <div class="alert alert-danger">
                            <h1>Your registration doesnot started yet</h1>
                            <a class="btn btn-secondary" href="<?php echo e(route('student.home')); ?>">Back</a>
                        </div> 
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('user.masterPage', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH H:\University Management\UniversityManagement\resources\views/user/courseregistration/start.blade.php ENDPATH**/ ?>