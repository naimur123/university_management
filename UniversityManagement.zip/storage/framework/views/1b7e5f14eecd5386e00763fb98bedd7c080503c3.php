                 </div>
                </div>
            </div>
            
    </div>
    
    
   
</body>
</html>
<?php /**PATH H:\University Management\UniversityManagement\resources\views/user/includes/footer.blade.php ENDPATH**/ ?>